# Product Management Opportunity Evaluator Skill

## What This Skill Does

The **pm-opportunity-evaluator** skill provides a systematic framework for evaluating product management job opportunities. When you use this skill, Claude will:

1. **Interview you systematically** about a specific job opportunity using proven diagnostic frameworks
2. **Research the company externally** using web search to gather current news, employee reviews (Glassdoor, etc.), and product/market context with publication dates and source links
3. **Pattern match job description language against research findings** to decode what they're really saying (e.g., "navigate complex stakeholders" + Glassdoor "political environment" = dysfunction)
4. **Analyze the job posting** to identify red/green flags and decode what the company actually needs
5. **Assess fit** across multiple dimensions (context, capability, culture, role clarity, strategic)
6. **Produce stage-appropriate deliverables** based on where you are in the process:
   - **Considering/Invited**: Recommendation + tailored resume + cover letter
   - **Interviewing**: Assessment + customized questions to ask + evaluation framework
   - **Offer/Negotiating**: Compensation analysis + negotiation strategy + go/no-go recommendation

## Key Features

### Challenging and Incisive
The skill is designed to push back on assumptions and surface uncomfortable truths. It will:
- Recommend *against* opportunities when appropriate
- Challenge you on red flags you might be ignoring
- **Research the company externally** to validate claims and surface issues (Glassdoor reviews, recent news, product reception) with dates and source links
- **Pattern match** job posting language against research to decode hidden meanings (e.g., "navigate complex stakeholders" + multiple Glassdoor reviews about "political environment" = organizational dysfunction)
- Adapt recommendations based on your real constraints (timeline, money, other offers)
- Focus on "right opportunity for you right now" vs. abstract perfection

### Comprehensive Frameworks
Built on a 14-section assessment framework, the skill covers:
- Candidate archetypes (Builder, Scaler, Navigator, Portfolio Strategist, Transformer)
- Role pattern recognition across all levels (PM → CPO)
- Industry-specific patterns (B2B SaaS, Gaming, Consumer, Enterprise)
- Level readiness assessment
- "Valuable vs. Bitter" coaching framework
- Red/green flag reference library

### Stage-Appropriate Outputs
Deliverables automatically adapt to your stage:
- Early stage: Focus on whether to pursue + positioning
- Interview stage: Strategic questions + evaluation framework
- Offer stage: Compensation analysis + negotiation scripts

## How to Use

1. **Install the skill** 
   - Go to **Settings > Capabilities > Upload Skill**
   - Upload the `pm-opportunity-evaluator.skill` file
2. **Trigger it** by mentioning you're considering a product management role, preparing for interviews, or evaluating an offer
3. **Follow the workflow**: Claude will guide you through information collection and strategic interview
4. **Receive deliverables**: Tailored outputs for your specific situation

## What's Included

The skill file (`pm-opportunity-evaluator.skill`) contains:

- **Complete workflow instructions** including step-by-step assessment process, interview question frameworks, deliverable templates, quality standards, and common pattern recognition
- **External research protocols** with systematic web search strategies, documentation requirements (dates, links, quotes), and pattern-matching frameworks that decode job posting language against real employee/market feedback
- **Comprehensive reference framework** covering candidate assessment, job posting analysis, role pattern recognition, fit assessment matrices, interview question banks, resume positioning strategies, industry-specific patterns, negotiation frameworks, and red/green flag libraries

## Framework Development

This skill is built on extensive research and pattern analysis:
- **500+ active job postings** analyzed (current as of November 2025) across PM, Senior PM, Director, VP, and CPO levels
- **Cross-industry pattern extraction** spanning B2B SaaS, consumer tech, gaming, fintech, and enterprise platforms
- **Multi-stage company analysis** from seed-stage startups to public companies, identifying how requirements shift across organizational maturity
- **Role archetype identification** through systematic coding of job requirements, responsibilities, and success criteria
- **Real-world validation** against actual hiring outcomes and placement success factors

The frameworks distill years of executive search experience and deep pattern recognition into actionable assessment tools that work for any PM role, at any level, in any industry.

## Example Usage

**You:** "I'm considering applying for a Director of Product role at a Series B SaaS company. Can you help me evaluate if it's a good fit?"

**Claude:** [Activates pm-opportunity-evaluator skill]
"I'm going to help you systematically evaluate this opportunity. This will involve collecting information about the role and company, asking you targeted questions about your experience and situation, and producing specific deliverables based on where you are in the process.

How much time do you have for this assessment?
- Quick (15-20 minutes): Focused evaluation with core deliverables
- Standard (30-40 minutes): Comprehensive assessment with all deliverables
- Deep (60+ minutes): Extended interview with detailed analysis"

[Proceeds through structured interview, then delivers:]
- Fit assessment with clear recommendation
- Tailored resume optimized for the role
- Cover letter addressing key requirements
- Positioning strategy for any gaps

## Notes

This skill is designed for product managers at **all levels** (PM, Senior PM, Director, VP, SVP, CPO). The assessment frameworks scale with role level:
- **PM/Senior PM**: Focus on execution, decision-making, and influence
- **Director**: System building, team leadership, and portfolio management
- **VP/CPO**: Capital allocation, hypothesis generation, and organizational transformation

The skill will NOT just validate what you want to hear. It's built to challenge assumptions and provide honest assessments, even if that means recommending against an opportunity you're excited about.

---

**Created**: November 2025  
**Created by**: Chris Spagnuolo  
**Based on**: "Product Management Job Search: Candidate Assessment & Role Evaluation Guide" by Chris Spagnuolo  
**Contact**: https://www.linkedin.com/in/chrisspagnuolo/
