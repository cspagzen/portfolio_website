# Product Management Opportunity Evaluator Skill

## What This Skill Does

The **pm-opportunity-evaluator** skill transforms your comprehensive product management job search guide into an interactive assessment tool. When you use this skill, Claude will:

1. **Interview you systematically** about a specific job opportunity using proven diagnostic frameworks
2. **Analyze the job posting** to identify red/green flags and decode what the company actually needs
3. **Assess fit** across multiple dimensions (context, capability, culture, role clarity, strategic)
4. **Produce stage-appropriate deliverables** based on where you are in the process:
   - **Considering/Invited**: Recommendation + tailored resume + cover letter
   - **Interviewing**: Assessment + customized questions to ask + evaluation framework
   - **Offer/Negotiating**: Compensation analysis + negotiation strategy + go/no-go recommendation

## Key Features

### Challenging and Incisive
The skill is designed to push back on assumptions and surface uncomfortable truths. It will:
- Recommend *against* opportunities when appropriate
- Challenge you on red flags you might be ignoring
- Adapt recommendations based on your real constraints (timeline, money, other offers)
- Focus on "right opportunity for you right now" vs. abstract perfection

### Comprehensive Frameworks
Based on your 14-section assessment guide, the skill covers:
- Candidate archetypes (Builder, Scaler, Navigator, Portfolio Strategist, Transformer)
- Role pattern recognition across all levels (PM → CPO)
- Industry-specific patterns (B2B SaaS, Gaming, Consumer, Enterprise)
- Level readiness assessment
- "Valuable vs. Bitter" coaching framework
- Red/green flag reference library

### Stage-Appropriate Outputs
Deliverables automatically adapt to your stage:
- Early stage: Focus on whether to pursue + positioning
- Interview stage: Strategic questions + evaluation framework
- Offer stage: Compensation analysis + negotiation scripts

## How to Use

1. **Install the skill** in your Claude project
2. **Trigger it** by mentioning you're considering a product management role, preparing for interviews, or evaluating an offer
3. **Follow the workflow**: Claude will guide you through information collection and strategic interview
4. **Receive deliverables**: Tailored outputs for your specific situation

## What's Included

The skill contains:

### SKILL.md
Complete workflow instructions including:
- Step-by-step assessment process
- Interview question frameworks
- Deliverable templates
- Quality standards
- Common pattern recognition

### references/pm-job-guide.md
Comprehensive reference guide with:
- Section 1: Candidate Assessment Framework (diagnostic questions, archetypes)
- Section 2: Job Posting Decoder (translation guide, red/green flags by level)
- Section 3: Role Pattern Recognition (PM/Director/Exec models)
- Section 4: Fit Assessment Matrix
- Section 5: Interview Question Bank
- Section 6: Resume Positioning Strategy
- Section 7: Industry-Specific Patterns
- Section 8: "Valuable vs. Bitter" Framework
- Section 9: Red/Green Flags Reference
- Section 10: Negotiation Strategy

## Example Usage

**You:** "I'm considering applying for a Director of Product role at a Series B SaaS company. Can you help me evaluate if it's a good fit?"

**Claude:** [Activates exec-opportunity-evaluator skill]
"I'm going to help you systematically evaluate this opportunity. This will involve collecting information about the role and company, asking you targeted questions about your experience and situation, and producing specific deliverables based on where you are in the process.

How much time do you have for this assessment?
- Quick (15-20 minutes): Focused evaluation with core deliverables
- Standard (30-40 minutes): Comprehensive assessment with all deliverables
- Deep (60+ minutes): Extended interview with detailed analysis"

[Proceeds through structured interview, then delivers:]
- Fit assessment with clear recommendation
- Tailored resume optimized for the role
- Cover letter addressing key requirements
- Positioning strategy for any gaps

## Technical Details

- **Type**: Workflow-based skill with reference documentation
- **Size**: ~50KB compressed
- **Resources**: 1 SKILL.md + 1 comprehensive reference guide
- **No scripts/assets needed**: Pure knowledge + workflow skill

## Notes

This skill is designed for product managers at **all levels** (PM, Senior PM, Director, VP, SVP, CPO). The assessment frameworks scale with role level:
- **PM/Senior PM**: Focus on execution, decision-making, and influence
- **Director**: System building, team leadership, and portfolio management
- **VP/CPO**: Capital allocation, hypothesis generation, and organizational transformation

The skill will NOT just validate what you want to hear. It's built to challenge assumptions and provide honest assessments, even if that means recommending against an opportunity you're excited about.

---

**Created**: November 2024  
**Based on**: Product Management Job Search: Candidate Assessment & Role Evaluation Guide
